#!/usr/bin/env bash
# Start PhishGuard on Mac / Linux:   bash run.sh
# It installs Flask (first time only), starts the server and opens the web page.
cd "$(dirname "$0")" || exit 1
python3 -m pip install -r requirements.txt
python3 app.py
