@echo off
rem Double-click this file to start PhishGuard on Windows.
rem It installs Flask (first time only), starts the server and opens the web page.
cd /d "%~dp0"
echo Installing requirements (first time only)...
python -m pip install -r requirements.txt
if errorlevel 1 (
    echo.
    echo Could not install Flask. Is Python installed and added to PATH?
    pause
    exit /b 1
)
echo.
python app.py
pause
