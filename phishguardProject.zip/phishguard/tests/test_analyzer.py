"""
Tests for analyzer.py.

Run from the project folder with:   python -m unittest -v

A test is a tiny program that checks "when I give the analyzer THIS link, does
it give the answer I expect?". Tests protect you from breaking old features
when you add new ones.
"""

import unittest

from analyzer import analyze_url, registered_domain


def finding_ids(result):
    """Helper: just the list of finding ids, e.g. ['ip-address', 'no-https']."""
    return [f["id"] for f in result["findings"]]


class InputValidationTests(unittest.TestCase):
    def test_empty_input_is_rejected(self):
        with self.assertRaises(ValueError):
            analyze_url("   ")

    def test_spaces_are_rejected(self):
        with self.assertRaises(ValueError):
            analyze_url("http://example.com/a b")

    def test_non_http_scheme_is_rejected(self):
        with self.assertRaises(ValueError):
            analyze_url("ftp://example.com/file")

    def test_text_that_is_not_a_web_address_is_rejected(self):
        # Junk must never get a calm "no warning signs" verdict.
        for junk in ('=HYPERLINK("x")', "hello", "http://localhost", "<b>x</b>",
                     "http://[::1]/"):
            with self.assertRaises(ValueError, msg=junk):
                analyze_url(junk)

    def test_too_long_input_is_rejected(self):
        with self.assertRaises(ValueError):
            analyze_url("http://example.com/" + "a" * 3000)


class HelperTests(unittest.TestCase):
    def test_registered_domain(self):
        self.assertEqual(registered_domain("www.google.com"), "google.com")
        self.assertEqual(registered_domain("mail.google.co.in"), "google.co.in")
        self.assertEqual(registered_domain("paypal.com.evil.xyz"), "evil.xyz")


class DetectionTests(unittest.TestCase):
    def test_ip_address_is_flagged(self):
        result = analyze_url("http://192.168.1.5/login")
        self.assertIn("ip-address", finding_ids(result))

    def test_lookalike_brand_is_flagged(self):
        result = analyze_url("http://paypa1-secure-login.xyz/verify/account")
        self.assertIn("brand-impersonation", finding_ids(result))
        self.assertEqual(result["verdict"]["level"], "danger")

    def test_brand_in_subdomain_trick(self):
        # Typed without http:// on purpose.
        result = analyze_url("paypal.com.evil.xyz/login")
        self.assertIn("brand-impersonation", finding_ids(result))
        # We did not see the start of the link, so no HTTPS verdict.
        self.assertNotIn("no-https", finding_ids(result))

    def test_real_brand_domain_is_not_flagged_as_impersonation(self):
        result = analyze_url("https://www.paypal.com/signin")
        self.assertNotIn("brand-impersonation", finding_ids(result))

    def test_generic_word_is_not_a_false_alarm(self):
        # 'apple' inside 'pineapple' must not be treated as Apple Inc.
        result = analyze_url("https://pineapple.com/recipes")
        self.assertNotIn("brand-impersonation", finding_ids(result))

    def test_amazonaws_is_not_flagged(self):
        result = analyze_url("https://my-bucket.s3.amazonaws.com/file.txt")
        self.assertNotIn("brand-impersonation", finding_ids(result))

    def test_at_sign_trick(self):
        result = analyze_url("http://paypal.com@evil.xyz/login")
        self.assertIn("at-sign", finding_ids(result))

    def test_punycode_lookalike(self):
        result = analyze_url("http://xn--pypal-4ve.com")
        self.assertIn("lookalike-characters", finding_ids(result))

    def test_shortener(self):
        result = analyze_url("https://bit.ly/3Xy9AbC")
        self.assertIn("url-shortener", finding_ids(result))

    def test_apk_download(self):
        result = analyze_url("https://example.com/files/bank-rewards.apk")
        self.assertIn("risky-download", finding_ids(result))

    def test_embedded_link(self):
        result = analyze_url("https://example.com/go?next=http://other.example/")
        self.assertIn("embedded-link", finding_ids(result))

    def test_odd_port(self):
        result = analyze_url("https://example.com:8443/")
        self.assertIn("odd-port", finding_ids(result))

    def test_many_subdomains(self):
        result = analyze_url("https://a.b.c.d.example.com/")
        self.assertIn("many-subdomains", finding_ids(result))

    def test_http_without_padlock(self):
        result = analyze_url("http://example.com/")
        self.assertIn("no-https", finding_ids(result))

    def test_javascript_link(self):
        result = analyze_url("javascript:alert(1)")
        self.assertIn("dangerous-scheme", finding_ids(result))


class HonestyTests(unittest.TestCase):
    """The tool must never promise that a link is safe."""

    def test_clean_link_is_never_called_safe(self):
        result = analyze_url("https://en.wikipedia.org/wiki/Phishing")
        self.assertEqual(result["findings"], [])
        self.assertEqual(result["verdict"]["level"], "low")
        self.assertNotIn("safe", result["verdict"]["label"].lower())
        self.assertIn("NOT", result["verdict"]["summary"])
        self.assertIn("NOT a guarantee", result["disclaimer"])

    def test_score_never_exceeds_100(self):
        result = analyze_url(
            "http://paypa1-secure-login-update.xyz:8080/verify/account/otp/"
            "kyc/refund.apk?next=http://evil.example/"
        )
        self.assertLessEqual(result["score"], 100)


if __name__ == "__main__":
    unittest.main()
