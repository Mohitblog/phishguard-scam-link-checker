"""Tests for the machine-learning part (ml.py) and the combiner (engine.py)."""

import unittest

import ml
from engine import MAX_BATCH, check_many, check_url


class FeatureTests(unittest.TestCase):
    def test_feature_count_matches_names(self):
        values = ml.extract("https://www.example.com/path?x=1")
        self.assertEqual(len(values), len(ml.FEATURE_NAMES))

    def test_features_are_correct_for_a_known_link(self):
        values = dict(zip(ml.FEATURE_NAMES, ml.extract("http://192.168.1.5:8080/login")))
        self.assertEqual(values["is_ip"], 1)
        self.assertEqual(values["odd_port"], 1)
        self.assertEqual(values["uses_https"], 0)
        self.assertEqual(values["keyword_hits"], 1)  # 'login'

    def test_link_without_scheme_is_not_punished_for_missing_https(self):
        values = dict(zip(ml.FEATURE_NAMES, ml.extract("example.com/page")))
        self.assertEqual(values["uses_https"], 1)

    def test_unparsable_link_raises(self):
        with self.assertRaises(ValueError):
            ml.extract("http://")


class ModelTests(unittest.TestCase):
    def test_model_file_matches_feature_list(self):
        model = ml.load_model()
        self.assertIsNotNone(model, "run python train_model.py to create model.json")
        self.assertEqual(model["feature_names"], ml.FEATURE_NAMES)

    def test_probability_is_between_0_and_1(self):
        for url in ["https://en.wikipedia.org", "http://paypa1-secure-login.xyz/verify",
                    "http://1.2.3.4/a", "https://bit.ly/abc"]:
            probability = ml.predict(url)["probability"]
            self.assertGreaterEqual(probability, 0.0)
            self.assertLessEqual(probability, 1.0)

    def test_scam_looking_link_scores_higher_than_normal_link(self):
        scam = ml.predict("http://paypa1-secure-login.xyz/verify/account")["probability"]
        normal = ml.predict("https://en.wikipedia.org/wiki/Phishing")["probability"]
        self.assertGreater(scam, 0.8)
        self.assertLess(normal, 0.3)

    def test_factors_explain_the_answer(self):
        factors = ml.predict("http://paypa1-secure-login.xyz/verify/account")["factors"]
        self.assertTrue(factors)
        self.assertIn("scam", {f["effect"] for f in factors})
        for factor in factors:
            self.assertIn(factor["effect"], ("scam", "normal"))
            self.assertTrue(0 < factor["pct"] <= 100)

    def test_predict_returns_none_for_unusable_input(self):
        self.assertIsNone(ml.predict("http://"))

    def test_summary_for_model_page(self):
        summary = ml.model_summary()
        self.assertEqual(summary["feature_count"], len(ml.FEATURE_NAMES))
        self.assertIn("accuracy", summary["metrics"])


class EngineTests(unittest.TestCase):
    def test_combined_result_has_both_opinions(self):
        result = check_url("http://paypa1-secure-login.xyz/verify/account")
        self.assertIsNotNone(result["ml"])
        self.assertGreaterEqual(result["score"], 65)
        self.assertEqual(result["verdict"]["level"], "danger")

    def test_clean_link_is_never_called_safe(self):
        result = check_url("https://en.wikipedia.org/wiki/Phishing")
        self.assertEqual(result["verdict"]["level"], "low")
        self.assertNotIn("safe", result["verdict"]["label"].lower())
        self.assertIn("NOT a guarantee", result["disclaimer"])

    def test_score_stays_in_range(self):
        result = check_url("http://paypa1-secure-login-update.xyz:8080/verify/otp/kyc.apk?next=http://evil.example/")
        self.assertLessEqual(result["score"], 100)

    def test_anatomy_finds_real_owner(self):
        anatomy = check_url("https://paypal.com.evil.xyz/login")["anatomy"]
        self.assertEqual(anatomy["owner"], "evil.xyz")
        self.assertEqual(anatomy["sub"], "paypal.com.")
        self.assertEqual(anatomy["scheme"], "https://")
        self.assertEqual(anatomy["rest"], "/login")

    def test_anatomy_marks_ignored_part_before_at_sign(self):
        anatomy = check_url("http://paypal.com@evil.xyz/login")["anatomy"]
        self.assertEqual(anatomy["ignored"], "paypal.com@")
        self.assertEqual(anatomy["owner"], "evil.xyz")

    def test_invalid_input_still_raises(self):
        with self.assertRaises(ValueError):
            check_url("   ")


class BatchTests(unittest.TestCase):
    def test_batch_sorts_riskiest_first_and_reports_errors(self):
        rows, skipped = check_many(
            "https://en.wikipedia.org\nhttp://paypa1-secure-login.xyz\nbad link here"
        )
        self.assertEqual(skipped, 0)
        self.assertEqual(rows[0]["url"], "http://paypa1-secure-login.xyz")
        self.assertIn("error", rows[-1])

    def test_batch_removes_duplicates_and_limits_size(self):
        text = "\n".join(f"https://site{i}.example.com" for i in range(MAX_BATCH + 5))
        rows, skipped = check_many(text + "\nhttps://site0.example.com")
        self.assertEqual(len(rows), MAX_BATCH)
        self.assertEqual(skipped, 5)


if __name__ == "__main__":
    unittest.main()
