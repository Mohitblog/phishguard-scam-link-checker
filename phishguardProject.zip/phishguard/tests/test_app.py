"""Tests for the Flask web pages (app.py). Run with:  python -m unittest -v"""

import unittest

from app import app


class WebAppTests(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()

    def test_home_page_loads(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Is this link a trap?", response.data)

    def test_form_submission_shows_result(self):
        response = self.client.post(
            "/", data={"mode": "single", "url": "http://paypa1-secure-login.xyz/verify"}
        )
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"The link, taken apart", response.data)
        self.assertIn(b"Pretends to be PayPal", response.data)
        self.assertIn(b"machine-learning model", response.data)

    def test_empty_form_shows_friendly_error(self):
        response = self.client.post("/", data={"mode": "single", "url": ""})
        self.assertIn(b"Please paste a link first.", response.data)

    def test_user_input_is_escaped(self):
        # Whatever the user types must never be able to run as code.
        response = self.client.post(
            "/", data={"mode": "single", "url": "<script>alert(1)</script>"}
        )
        self.assertNotIn(b"<script>alert(1)</script>", response.data)

    def test_batch_form_shows_table(self):
        response = self.client.post("/", data={
            "mode": "batch",
            "urls": "http://paypa1-secure-login.xyz\nhttps://en.wikipedia.org/wiki/Phishing\nnot a link",
        })
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Results for 3 links", response.data)
        self.assertIn(b"Could not check", response.data)

    def test_empty_batch_shows_friendly_error(self):
        response = self.client.post("/", data={"mode": "batch", "urls": "  \n "})
        self.assertIn(b"Please paste at least one link", response.data)

    def test_model_page_loads(self):
        response = self.client.get("/model")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"How the model works", response.data)
        self.assertIn(b"generated", response.data)  # honest note about demo data

    def test_api_returns_json(self):
        response = self.client.post("/api/check", json={"url": "https://bit.ly/abc"})
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        for key in ("score", "rule_score", "ml", "findings", "verdict", "disclaimer"):
            self.assertIn(key, data)

    def test_api_rejects_missing_url(self):
        response = self.client.post("/api/check", json={})
        self.assertEqual(response.status_code, 400)

    def test_batch_api(self):
        response = self.client.post(
            "/api/batch", json={"urls": ["http://paypa1-login.xyz", "https://github.com"]}
        )
        self.assertEqual(response.status_code, 200)
        results = response.get_json()["results"]
        self.assertEqual(len(results), 2)
        self.assertGreaterEqual(results[0]["score"], results[1]["score"])  # riskiest first

    def test_batch_api_rejects_bad_body(self):
        response = self.client.post("/api/batch", json={"urls": "oops"})
        self.assertEqual(response.status_code, 400)


if __name__ == "__main__":
    unittest.main()
