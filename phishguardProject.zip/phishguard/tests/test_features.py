"""
Tests for the newer analyzer features: link anatomy, defanging, the report,
and the two bug fixes (IP owner, punycode hyphens).

Run from the project folder with:   python -m unittest -v
"""

import unittest

from analyzer import analyze_url, defang


def kinds(result):
    return [part["kind"] for part in result["details"]["anatomy"]]


def part_text(result, kind):
    for part in result["details"]["anatomy"]:
        if part["kind"] == kind:
            return part["text"]
    return None


class DefangTests(unittest.TestCase):
    def test_defang_makes_link_harmless(self):
        self.assertEqual(defang("http://evil.xyz/a"), "hxxp[:]//evil[.]xyz/a")
        self.assertEqual(defang("https://evil.xyz"), "hxxps[:]//evil[.]xyz")

    def test_result_contains_defanged_link(self):
        result = analyze_url("http://paypa1-secure-login.xyz/verify")
        self.assertTrue(result["defanged"].startswith("hxxp[:]//"))
        self.assertNotIn("http://", result["defanged"])


class AnatomyTests(unittest.TestCase):
    def test_subdomain_trick_shows_the_real_owner(self):
        result = analyze_url("https://paypal.com.secure-login.xyz/verify")
        self.assertEqual(kinds(result), ["scheme", "subdomain", "owner", "path"])
        self.assertEqual(part_text(result, "owner"), "secure-login.xyz")
        self.assertEqual(part_text(result, "subdomain"), "paypal.com.")

    def test_two_part_ending_keeps_three_words_in_owner(self):
        result = analyze_url("https://www.irctc.co.in/nget")
        self.assertEqual(part_text(result, "owner"), "irctc.co.in")

    def test_parts_rebuild_the_original_link(self):
        link = "https://www.example.com:8443/a/b?x=1"
        result = analyze_url(link)
        rebuilt = "".join(part["text"] for part in result["details"]["anatomy"])
        self.assertEqual(rebuilt, link)

    def test_at_sign_part_is_marked_as_ignored(self):
        result = analyze_url("http://paypal.com@evil.xyz/login")
        self.assertIn("userinfo", kinds(result))
        self.assertEqual(part_text(result, "owner"), "evil.xyz")

    def test_no_scheme_means_no_protocol_part(self):
        result = analyze_url("paypal.com.evil.xyz/login")
        self.assertNotIn("scheme", kinds(result))

    def test_javascript_link_has_no_anatomy(self):
        result = analyze_url("javascript:alert(1)")
        self.assertEqual(result["details"]["anatomy"], [])


class BugFixTests(unittest.TestCase):
    def test_ip_owner_is_the_whole_address(self):
        result = analyze_url("http://192.168.0.1:8080/login")
        self.assertEqual(result["details"]["registered_domain"], "192.168.0.1")
        self.assertEqual(part_text(result, "owner"), "192.168.0.1")
        self.assertTrue(result["details"]["is_ip"])

    def test_punycode_is_not_flagged_for_many_hyphens(self):
        result = analyze_url("http://xn--pypal-4ve.com/signin")
        ids = [f["id"] for f in result["findings"]]
        self.assertIn("lookalike-characters", ids)
        self.assertNotIn("many-hyphens", ids)


class ReportTests(unittest.TestCase):
    def test_report_uses_harmless_link_and_disclaimer(self):
        result = analyze_url("http://paypa1-secure-login.xyz/verify")
        report = result["report"]
        self.assertIn("hxxp[:]//", report)
        self.assertNotIn("http://", report)
        self.assertIn("Warning signs:", report)
        self.assertIn("NOT a guarantee", report)

    def test_report_for_clean_link_never_says_safe(self):
        report = analyze_url("https://en.wikipedia.org/wiki/Phishing")["report"]
        self.assertIn("none found in the text of the link", report)
        # The word "safe" may appear only inside the "NOT a guarantee" warning.
        without_warning = report.replace(
            "A low score is NOT a guarantee that a link is safe.", ""
        )
        self.assertNotIn("safe", without_warning.lower())


if __name__ == "__main__":
    unittest.main()
