"""
ml.py  -  the machine-learning "second opinion"
===============================================

HOW THE MACHINE LEARNING WORKS (simple version)
-----------------------------------------------
1. FEATURES: a computer cannot read a link the way we do, so we turn each link
   into 26 numbers (length of the link, number of hyphens, is it an IP address,
   how random the name looks ...). See the FEATURES list below.
2. TRAINING (done once in train_model.py): we show the computer thousands of
   links that are already labelled "scam" or "normal". It learns a WEIGHT for
   every feature: a positive weight means "more of this = more scam-like".
3. PREDICTING (this file): for a new link we compute the 26 numbers, multiply
   each by its learned weight, add everything up, and squash the total into a
   probability between 0 and 1 (the sigmoid function).

The trained model is saved as plain numbers in model.json. That means this file
can make predictions with ordinary Python, with no scikit-learn needed to RUN
the app (scikit-learn is only needed to TRAIN the model).

The model is "explainable": because the answer is just weights x features, we
can show which features pushed the answer toward "scam" or toward "normal".
"""

import json
import math
import os
import re
from urllib.parse import urlparse

from analyzer import (
    RISKY_EXTENSIONS,
    SHORTENERS,
    SUSPICIOUS_TLDS,
    SUSPICIOUS_WORDS,
    _brand_in_host,
    _is_ip_address,
    registered_domain,
)

MODEL_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "model.json")

# (feature name, plain-language description shown to the user)
FEATURES = [
    ("url_length", "Total length of the link"),
    ("host_length", "Length of the website name"),
    ("path_length", "Length of the page path after the website name"),
    ("query_length", "Length of the extra data after the '?'"),
    ("dots_in_host", "Number of dots in the website name"),
    ("subdomain_count", "Extra name parts before the real domain"),
    ("hyphens_in_host", "Number of hyphens in the website name"),
    ("digits_in_host", "Number of digits in the website name"),
    ("digit_ratio_url", "Share of the link made of digits"),
    ("special_chars", "Number of symbols such as ? & = % _ ~"),
    ("path_depth", "Number of folders in the path"),
    ("host_entropy", "How random the website name looks"),
    ("is_ip", "Website name is an IP address"),
    ("has_at", "Contains an '@' before the website name"),
    ("uses_https", "Uses HTTPS"),
    ("odd_port", "Uses an unusual port number"),
    ("keyword_hits", "Pressure words in the link (verify, otp, kyc ...)"),
    ("keyword_hits_in_host", "Pressure words inside the website name"),
    ("risky_tld", "Cheap or free domain ending"),
    ("is_shortener", "Is a short link"),
    ("has_punycode", "Uses look-alike letters from another alphabet"),
    ("brand_mismatch", "Pretends to be a famous brand"),
    ("embedded_url", "Contains another link inside it"),
    ("risky_extension", "Downloads an app or program file"),
    ("digit_letter_mix", "Words mixing digits and letters (like paypa1)"),
    ("longest_host_word", "Longest word in the website name"),
]
FEATURE_NAMES = [name for name, _ in FEATURES]
LABELS = dict(FEATURES)

# Features that are simply yes (1) or no (0) - shown as "Yes" / "No".
BINARY = {
    "is_ip", "has_at", "uses_https", "odd_port", "risky_tld", "is_shortener",
    "has_punycode", "brand_mismatch", "embedded_url", "risky_extension",
}


def _entropy(text):
    """Shannon entropy: higher = more random-looking text (like 'x7qk2pzv')."""
    if not text:
        return 0.0
    counts = {}
    for char in text:
        counts[char] = counts.get(char, 0) + 1
    total = len(text)
    return -sum((n / total) * math.log2(n / total) for n in counts.values())


# --------------------------------------------------------------------------
# 1. LINK  ->  26 NUMBERS
# --------------------------------------------------------------------------

def extract(raw_url):
    """Turn one link into a list of 26 numbers (in FEATURE_NAMES order)."""
    raw = raw_url.strip()
    lowered = raw.lower()
    had_scheme = bool(re.match(r"^[a-z][a-z0-9+.\-]*://", lowered))
    url = raw if had_scheme else "http://" + raw

    parsed = urlparse(url)
    host = (parsed.hostname or "").lower().rstrip(".")
    if not host:
        raise ValueError("no host name found")
    try:
        port = parsed.port
    except ValueError:
        port = None

    is_ip = _is_ip_address(host)
    owner = registered_domain(host)
    path = parsed.path or ""
    query = parsed.query or ""
    words = [w for w in re.split(r"[.\-_]", host) if w]
    haystack = (host + path).lower()

    subdomains = 0
    if not is_ip and host != owner:
        sub_part = host[: -len(owner)].strip(".")
        subdomains = len([s for s in sub_part.split(".") if s])

    tld = host.rsplit(".", 1)[-1] if "." in host else ""
    inner = (path + "?" + query).lower()
    digits_in_url = sum(c.isdigit() for c in url)

    values = {
        "url_length": len(url),
        "host_length": len(host),
        "path_length": len(path),
        "query_length": len(query),
        "dots_in_host": host.count("."),
        "subdomain_count": subdomains,
        "hyphens_in_host": host.count("-"),
        "digits_in_host": sum(c.isdigit() for c in host),
        "digit_ratio_url": digits_in_url / max(1, len(url)),
        "special_chars": sum(url.count(c) for c in "?&=%_~"),
        "path_depth": path.count("/"),
        "host_entropy": _entropy(host),
        "is_ip": int(is_ip),
        "has_at": int("@" in parsed.netloc),
        # If the user pasted a link without http/https we cannot know, so we
        # treat it as neutral (1) instead of punishing it.
        "uses_https": int(parsed.scheme == "https" or not had_scheme),
        "odd_port": int(port not in (None, 80, 443)),
        "keyword_hits": sum(w in haystack for w in SUSPICIOUS_WORDS),
        "keyword_hits_in_host": sum(w in host for w in SUSPICIOUS_WORDS),
        "risky_tld": int(tld in SUSPICIOUS_TLDS),
        "is_shortener": int(owner in SHORTENERS),
        "has_punycode": int("xn--" in host or not host.isascii()),
        "brand_mismatch": int(not is_ip and _brand_in_host(host, owner) is not None),
        "embedded_url": int(bool(re.search(r"https?(://|%3a%2f%2f)", inner))),
        "risky_extension": int(path.lower().endswith(RISKY_EXTENSIONS)),
        "digit_letter_mix": sum(
            1 for w in words
            if any(c.isdigit() for c in w) and any(c.isalpha() for c in w)
        ),
        "longest_host_word": max((len(w) for w in words), default=0),
    }
    return [float(values[name]) for name in FEATURE_NAMES]


# --------------------------------------------------------------------------
# 2. LOAD THE TRAINED MODEL
# --------------------------------------------------------------------------

_model_cache = {"loaded": False, "model": None}


def load_model():
    """Read model.json once. Returns None if it is missing or broken."""
    if not _model_cache["loaded"]:
        _model_cache["loaded"] = True
        try:
            with open(MODEL_PATH, encoding="utf-8") as handle:
                model = json.load(handle)
            if model.get("feature_names") != FEATURE_NAMES:
                raise ValueError("model.json does not match the feature list")
            _model_cache["model"] = model
        except (OSError, ValueError):
            _model_cache["model"] = None
    return _model_cache["model"]


def _format_value(name, value):
    if name in BINARY:
        return "Yes" if value >= 0.5 else "No"
    if name == "digit_ratio_url":
        return f"{value * 100:.0f}%"
    if name == "host_entropy":
        return f"{value:.2f}"
    return str(int(round(value)))


# --------------------------------------------------------------------------
# 3. PREDICT
# --------------------------------------------------------------------------

def predict(raw_url, top_n=5):
    """
    Return the model's opinion about one link, or None if no model is available.

    {
      "probability": 0.97,        # 0 = normal-looking, 1 = scam-looking
      "percent": 97,
      "factors": [ {label, value_text, effect, pct}, ... ]   # why
    }
    """
    model = load_model()
    if model is None:
        return None
    try:
        x = extract(raw_url)
    except ValueError:
        return None

    # contribution of each feature = weight * (how unusual the value is)
    contributions = []
    for i, value in enumerate(x):
        scaled = (value - model["mean"][i]) / model["scale"][i]
        contributions.append(model["coef"][i] * scaled)

    z = model["intercept"] + sum(contributions)
    z = max(-30.0, min(30.0, z))
    probability = 1 / (1 + math.exp(-z))  # sigmoid: any number -> 0..1

    ranked = sorted(range(len(x)), key=lambda i: abs(contributions[i]), reverse=True)
    shown = [i for i in ranked if abs(contributions[i]) >= 0.25][:top_n]
    biggest = max((abs(contributions[i]) for i in shown), default=1.0)

    factors = []
    for i in shown:
        name = FEATURE_NAMES[i]
        factors.append({
            "label": LABELS[name],
            "value_text": _format_value(name, x[i]),
            "effect": "scam" if contributions[i] > 0 else "normal",
            "pct": max(6, round(abs(contributions[i]) / biggest * 100)),
        })

    return {
        "probability": probability,
        "percent": round(probability * 100),
        "factors": factors,
    }


def model_summary():
    """Everything the 'How the model works' page needs, or None."""
    model = load_model()
    if model is None:
        return None
    weights = sorted(
        (
            {"label": LABELS[name], "weight": model["coef"][i]}
            for i, name in enumerate(FEATURE_NAMES)
        ),
        key=lambda item: item["weight"],
        reverse=True,
    )
    biggest = max(abs(w["weight"]) for w in weights) or 1.0
    for item in weights:
        item["pct"] = max(2, round(abs(item["weight"]) / biggest * 100))
        item["effect"] = "scam" if item["weight"] > 0 else "normal"
    return {
        "metrics": model["metrics"],
        "trained_on": model["trained_on"],
        "weights": weights,
        "feature_count": len(FEATURE_NAMES),
    }
