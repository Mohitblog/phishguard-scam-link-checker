# PhishGuard - Scam & Phishing Link Checker

A small web app that checks a suspicious link (from SMS, email or social media) and explains, **in plain language, why it looks risky**.

> **Honesty rule:** PhishGuard never calls a link "safe". It only reads how the link is *written*. The best result it can give is *"No obvious warning signs"*, with a reminder that this is not a guarantee.

## Features

- Paste a URL and get a **risk score from 0 to 100**
- Detects **15 suspicious patterns** with hand-written rules (list below)
- **Machine-learning second opinion:** a trained model rates the link and shows *which measurements* pushed its answer
- **Link taken apart:** the page splits the link into parts and highlights who really owns the website
- **Check many links at once** (up to 20) with a downloadable CSV report
- **"How the model works" page** with accuracy numbers and the weights the model learned
- Clean, responsive design with automatic dark mode
- **Beginner-friendly explanation** for every warning sign (the unique part of this project)
- Advice on what to do next, plus safe browsing tips
- JSON API (`/api/check`) so other programs can use it
- Never opens the link, so checking it cannot harm you
- Automated tests for the rules, the ML model, the combiner and the web pages

## Quick start

**Easiest way:**
- **Windows:** double-click `run.bat`
- **Mac / Linux:** run `bash run.sh`

The server starts and the web page **opens in your browser automatically**.
(To stop the auto-open, set the environment variable `PHISHGUARD_NO_BROWSER=1`.)

**Step-by-step way:**

```bash
# 1. (optional) create a virtual environment
python -m venv venv
venv\Scripts\activate          # Windows
source venv/bin/activate       # Mac / Linux

# 2. install the only dependency
pip install -r requirements.txt

# 3. run the app
python app.py
```

The page opens automatically. If it does not, open **http://127.0.0.1:5000** in your browser.

Run the tests:

```bash
python -m unittest -v
```

## Project structure

```
phishguard/
├── app.py              # Flask web server: pages and the JSON API
├── engine.py           # Combines the rule score and the ML score
├── analyzer.py         # Rule-based checks and explanations
├── ml.py               # ML: link -> 26 numbers -> probability (+ explanation)
├── train_model.py      # Trains the model and writes model.json
├── model.json          # The trained model (just numbers, no extra libraries needed)
├── run.bat / run.sh    # One-click launchers (Windows / Mac-Linux)
├── templates/
│   ├── base.html       # Shared page frame
│   ├── index.html      # Check one or many links
│   └── model.html      # "How the model works" page
├── static/
│   └── style.css       # Look and feel (includes dark mode)
├── tests/              # Unit and integration tests
├── requirements.txt    # Flask (all you need to RUN the app)
├── requirements-train.txt   # scikit-learn + numpy (only to RE-TRAIN)
└── README.md
```

## The machine-learning part

PhishGuard has **two judges**: the rule check and a machine-learning model. Their scores are combined: `70% rules + 30% ML`. If they disagree strongly, the page says so.

**How the model works**
1. **Features:** each link is turned into 26 numbers (length, hyphens, digits, is it an IP, how random the name looks, brand mismatch, ...). See `FEATURES` in `ml.py`.
2. **Training:** `train_model.py` shows a Logistic Regression model thousands of labelled links (scam / normal). It learns a weight for each feature. 20% of the links are hidden and used only for testing.
3. **Prediction:** `ml.py` multiplies each feature by its weight, adds them up, and turns the total into a probability (sigmoid function).

**Why Logistic Regression?** It is explainable: the answer is just weights x features, so the page can show *which features pushed the answer* toward "scam" or "normal". A Random Forest is trained alongside for comparison and scores a little higher, but it cannot explain itself as clearly.

**Why `model.json`?** The trained model is saved as plain numbers, so the web app needs only Flask to run. scikit-learn is needed only if you re-train.

### Be honest about the data
The shipped model was trained on **synthetic (generated) example links**, so its test score (about 92%) shows how well it learned those patterns, **not** how well it works on real scams. This is stated on the "How the model works" page. To make it a real result, train on a real dataset:

```bash
pip install -r requirements-train.txt
python train_model.py --csv real_links.csv
```

The CSV needs two columns: `url,label` (label `1` = phishing, `0` = normal). Public sources: the Kaggle "Phishing Site URLs" and "Malicious URLs" datasets, and the PhishTank / OpenPhish feeds for phishing links (pair them with a list of popular, legitimate domains such as the Tranco list). After training, the page shows the new numbers automatically.

Re-train without a CSV (generated data) with `python train_model.py`.

## How the rule check works

```
Browser form --> app.py (Flask route) --> analyzer.analyze_url() --> result page
```

1. The user pastes a link. `app.py` sends it to `analyze_url()`.
2. `analyze_url()` cleans the input, splits the link into parts (protocol, host, path ...) and runs the checks one by one.
3. Each check that finds something adds a **finding** with a title, a simple explanation, a severity and some points.
4. The points are added up (maximum 100) and mapped to a verdict.

| Score | Verdict |
|-------|---------|
| 0-9   | No obvious warning signs (never "safe") |
| 10-34 | A few warning signs |
| 35-64 | Looks suspicious |
| 65-100 | Very likely a scam link |

## What it checks

| # | Warning sign | Points | Why scammers do it |
|---|--------------|--------|--------------------|
| 1 | `@` inside the link | 25 | Browser ignores the text before `@`, so a trusted name hides the real site |
| 2 | IP address instead of a name | 30 | Hides who owns the site |
| 3 | Look-alike letters (punycode) | 25 | A fake "paypal.com" built with letters from another alphabet |
| 4 | Brand impersonation (`paypa1`, `paypal.com.evil.xyz`) | 35 | Pretends to be a bank or famous company |
| 5 | Brand name only in the path | 15 | `evil.com/paypal/login` is just a folder name |
| 6 | URL shortener | 15 | Hides the real destination |
| 7 | App or program download (`.apk`, `.exe`) | 20 | Fake bank / reward apps |
| 8 | Another link hidden inside the link | 10 | Redirect tricks |
| 9 | Cheap or free domain ending (`.xyz`, `.top` ...) | 10 | Weak signal on its own |
| 10 | Many sub-domains | 8 | Pushes the real owner out of sight |
| 11 | Many hyphens in the domain | 6 | `secure-login-bank-update.com` |
| 12 | Pressure words (`verify`, `otp`, `kyc`, `refund` ...) | 5-15 | Creates urgency, weak signal |
| 13 | No HTTPS | 10 | Not encrypted (but HTTPS does not prove a site is honest) |
| 14 | Unusual port number | 8 | Temporary or hacked servers |
| 15 | Very long link / heavy `%xx` encoding | 5 | Hides the important part |

## JSON API

```bash
curl -X POST http://127.0.0.1:5000/api/check \
     -H "Content-Type: application/json" \
     -d '{"url": "http://paypa1-secure-login.xyz"}'
```

Returns `score` (combined), `rule_score`, `ml` (probability and factors), `verdict`, `findings`, `details`, `anatomy` and `disclaimer`.

Check many links at once: `POST /api/batch` with `{"urls": ["link1", "link2"]}`.

## Security design decisions

- **The link is never opened or downloaded.** Only its text is analyzed.
- User input is **escaped** by the template engine and shown as plain text, not as a clickable link (tested in `test_user_input_is_escaped`).
- Input is limited to 2048 characters, and spaces and non-http schemes are rejected.
- Error messages never echo user input back.
- Debug mode is **off** by default.
- The result always includes a disclaimer, and a low score is never labelled "safe".

## Limitations (be honest about these in interviews)

- It only analyzes the **text** of the link, not the website, so it can miss brand-new scams and can raise false alarms on honest links.
- The brand list is small (about 22 brands, many Indian ones). Add more in `BRANDS` in `analyzer.py`.
- The main-domain detection is a simple approximation; production code would use the `tldextract` library.
- A public deployment would need rate limiting.

## Ideas to extend it

1. **Real data:** retrain on a real phishing dataset and report honest precision / recall.
2. **Domain age** with a WHOIS lookup (new domains are riskier).
3. **Google Safe Browsing API** or VirusTotal as an extra opinion.
4. **Browser extension** that calls `/api/check` from a right-click menu.
5. **History page** using SQLite to store checked links.
6. **Hindi and other languages** for the explanations, which is very helpful for real users.

## Resume / LinkedIn description

**PhishGuard - Scam & Phishing Link Checker** | Python, Flask, scikit-learn, HTML/CSS, REST API, unittest
- Built a Flask web app that analyzes URLs for 15 phishing patterns (look-alike brand domains, IP hosts, URL shorteners, hidden redirects, risky downloads) and returns a 0-100 risk score.
- Designed a beginner-friendly explanation engine that tells users *why* a link looks suspicious, with clear next steps.
- Applied secure coding practices: input validation, output escaping, no fetching of untrusted URLs, and a "never labelled safe" policy.
- Trained a Logistic Regression model (scikit-learn) on 26 engineered URL features; combined it with the rule engine and surfaced per-prediction feature contributions so users see why a link was flagged.
- Added batch scanning with CSV export, a model-explainer page with held-out test metrics, and a JSON API; wrote unit and integration tests.

## How to explain this project in 30 seconds

"People get scam links on SMS and WhatsApp but don't know what to look for. I built a Flask app where you paste a link and it checks 15 patterns, like fake brand names, IP addresses and hidden redirects. It also runs a machine-learning model I trained and shows which measurements made it suspicious. It gives a risk score and explains each warning in simple language. It never opens the link and never claims a link is 100% safe, because it only reads the text of the link. My model is trained on generated demo data, so the next step is retraining on a real dataset."

## Disclaimer

This is a learning project. It is a helper, not a replacement for your own care. Never share OTP, PIN, CVV or passwords with anyone who contacted you first. In India, report cyber fraud at cybercrime.gov.in or call 1930.
