"""
engine.py  -  puts the two "opinions" together
==============================================

PhishGuard has two independent ways of judging a link:

  1. RULES  (analyzer.py): hand-written checks, each with a clear explanation.
  2. ML     (ml.py):       a model that learned patterns from example links.

This file runs both and merges them into one result for the web page.

    combined score = 70% rule score + 30% ML probability

Why the rules get more weight: they are transparent and every point can be
explained. The ML model is a second opinion that can notice combinations of
signs the rules do not cover. If the two disagree strongly we say so, instead
of hiding it.
"""

import re

from analyzer import _verdict_for, analyze_url
import ml

RULE_WEIGHT = 0.7
ML_WEIGHT = 0.3
DISAGREE_GAP = 40          # points of difference that count as "disagree"
MAX_BATCH = 20             # links per batch check


def _anatomy(raw, details):
    """
    Split the link into labelled pieces so the page can show it "taken apart":

        https://  [decoy@]  www.  paypal.com.evil.xyz  /login?x=1
        protocol   ignored   extra   REAL OWNER          page

    Returns None when the link has no normal host name.
    """
    host = details.get("host")
    owner = details.get("registered_domain")
    if not host or not owner:
        return None

    text = raw.strip()
    scheme_match = re.match(r"^[a-z][a-z0-9+.\-]*://", text, re.IGNORECASE)
    scheme = scheme_match.group(0) if scheme_match else ""
    rest = text[len(scheme):]

    # the host part ends at the first / ? or #
    end = len(rest)
    for stop in "/?#":
        position = rest.find(stop)
        if position != -1:
            end = min(end, position)
    netloc, tail = rest[:end], rest[end:]

    ignored = ""
    if "@" in netloc:
        before, netloc = netloc.rsplit("@", 1)
        ignored = before + "@"

    port = ""
    port_match = re.search(r":\d+$", netloc)
    if port_match:
        port = port_match.group(0)
        netloc = netloc[: -len(port)]

    sub = ""
    shown_owner = netloc
    if netloc.lower().endswith(owner) and netloc.lower() != owner:
        cut = len(netloc) - len(owner)
        sub, shown_owner = netloc[:cut], netloc[cut:]

    return {
        "scheme": scheme,
        "ignored": ignored,
        "sub": sub,
        "owner": shown_owner,
        "rest": port + tail,
    }


def check_url(raw_url):
    """Run rules + ML on one link. Raises ValueError for unusable input."""
    result = analyze_url(raw_url)          # may raise ValueError
    rule_score = result["score"]
    opinion = ml.predict(raw_url)

    if opinion is None:
        combined = rule_score
        note = None
    else:
        ml_points = opinion["probability"] * 100
        combined = round(RULE_WEIGHT * rule_score + ML_WEIGHT * ml_points)
        combined = min(100, combined)
        note = None
        if abs(rule_score - ml_points) >= DISAGREE_GAP:
            note = (
                "The rule check and the machine-learning model disagree about "
                "this link, so be extra careful and do not rely on the score "
                "alone."
            )

    result["rule_score"] = rule_score
    result["ml"] = opinion
    result["score"] = combined
    result["verdict"] = _verdict_for(combined)
    result["note"] = note
    result["anatomy"] = _anatomy(raw_url, result["details"])
    return result


def check_many(text):
    """
    Check several links (one per line). Returns (rows, skipped_count) where
    each row is a small dictionary ready to show in a table.
    """
    lines = []
    for line in text.splitlines():
        line = line.strip()
        if line and line not in lines:
            lines.append(line)
    skipped = max(0, len(lines) - MAX_BATCH)

    rows = []
    for line in lines[:MAX_BATCH]:
        try:
            result = check_url(line)
        except ValueError as problem:
            rows.append({"url": line, "error": str(problem)})
            continue
        top = result["findings"][0]["title"] if result["findings"] else \
            "No obvious warning signs"
        rows.append({
            "url": line,
            "score": result["score"],
            "level": result["verdict"]["level"],
            "label": result["verdict"]["label"],
            "reason": top,
            "ml_percent": result["ml"]["percent"] if result["ml"] else None,
        })
    rows.sort(key=lambda row: row.get("score", -1), reverse=True)
    return rows, skipped
