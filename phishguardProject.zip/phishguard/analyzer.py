"""
analyzer.py  -  the "brain" of PhishGuard
=========================================

WHAT THIS FILE DOES
-------------------
It receives a link (URL) as plain TEXT and looks for warning signs in the way
the link is written. Every warning sign adds some "risk points". The total
becomes a risk score from 0 to 100, and each warning sign comes with a simple,
beginner-friendly explanation.

WHAT THIS FILE DOES NOT DO (on purpose)
---------------------------------------
* It never opens, visits or downloads the link. Opening a bad link can be
  dangerous, and we only need the text of the link to find warning signs.
* It never says a link is "safe". A link can look completely normal and still
  be dangerous. The best honest answer is "no obvious warning signs found".

HOW TO READ THIS FILE
---------------------
1. The constants at the top are small "lists of knowledge" (shortener sites,
   risky endings, brand names ...). You can extend them easily.
2. `analyze_url()` is the main function. It runs one small check after another.
3. Each check appends a "finding" (a dictionary) to a list.
4. At the end the findings are turned into a score and a verdict.
"""

import ipaddress
import re
from urllib.parse import urlparse

# --------------------------------------------------------------------------
# 1. SETTINGS AND KNOWLEDGE LISTS
# --------------------------------------------------------------------------

MAX_URL_LENGTH = 2048  # refuse absurdly long input (protects the server)

DISCLAIMER = (
    "PhishGuard only checks how a link is written. It cannot look inside the "
    "website, so it can miss brand-new scams. A low score is NOT a guarantee "
    "that a link is safe."
)

# Websites that hide the real destination behind a short link.
SHORTENERS = {
    "bit.ly", "tinyurl.com", "t.co", "goo.gl", "is.gd", "cutt.ly", "rb.gy",
    "ow.ly", "shorturl.at", "tiny.cc", "buff.ly", "rebrand.ly", "s.id",
    "t.ly", "v.gd", "bl.ink",
}

# Endings (TLDs) that are very cheap or free, so scammers use them a lot.
# Plenty of honest sites use them too, so this is only a weak signal.
SUSPICIOUS_TLDS = {
    "xyz", "top", "tk", "ml", "ga", "cf", "gq", "click", "link", "zip", "mov",
    "work", "support", "buzz", "rest", "icu", "cam", "monster", "country",
    "loan", "men",
}

# Words scammers love because they create urgency or ask for private details.
SUSPICIOUS_WORDS = [
    "login", "signin", "verify", "secure", "account", "update", "confirm",
    "bank", "wallet", "password", "otp", "kyc", "reward", "prize", "claim",
    "free", "gift", "refund", "suspend", "unlock", "urgent", "invoice",
    "payment", "lottery", "winner",
]

# Files that can install harmful software. (.apk = Android app)
RISKY_EXTENSIONS = (".apk", ".exe", ".scr", ".bat", ".msi", ".jar", ".vbs")

# Link types that can run code instead of opening a website.
DANGEROUS_SCHEMES = ("javascript:", "data:", "vbscript:")

# Some domain endings have two parts (example: google.co.in). We need this to
# find the "main" domain name correctly without using an extra library.
TWO_PART_SUFFIXES = {
    "co.in", "ac.in", "gov.in", "nic.in", "org.in", "net.in", "edu.in",
    "res.in", "co.uk", "org.uk", "ac.uk", "gov.uk", "com.au", "co.jp",
    "co.za", "com.br",
}

# Famous brands that scammers pretend to be.
#   "keywords" : distinctive names - matched even inside longer words
#                (so "paypalsecure" and "paypa1" are caught).
#   "exact"    : generic words - only matched when they are a whole word
#                (so "apple-support" is caught but "pineapple" is not).
#   "domains"  : the REAL domains of that brand.
BRANDS = {
    "PayPal": {
        "keywords": ["paypal"], "exact": [],
        "domains": {"paypal.com", "paypal.me"},
    },
    "Amazon": {
        "keywords": ["amazon"], "exact": [],
        "domains": {"amazon.com", "amazon.in", "amazon.co.uk", "amazonaws.com",
                    "amazon.co.jp", "amazon.de"},
    },
    "Flipkart": {
        "keywords": ["flipkart"], "exact": [],
        "domains": {"flipkart.com"},
    },
    "Google": {
        "keywords": ["google"], "exact": [],
        "domains": {"google.com", "google.co.in", "googleapis.com",
                    "googleusercontent.com", "gstatic.com", "withgoogle.com",
                    "goo.gl"},
    },
    "Microsoft": {
        "keywords": ["microsoft"], "exact": [],
        "domains": {"microsoft.com", "microsoftonline.com", "office.com",
                    "live.com", "windows.net"},
    },
    "Apple": {
        "keywords": ["appleid", "icloud"], "exact": ["apple"],
        "domains": {"apple.com", "icloud.com"},
    },
    "Facebook": {
        "keywords": ["facebook"], "exact": [],
        "domains": {"facebook.com", "fb.com"},
    },
    "Instagram": {
        "keywords": ["instagram"], "exact": [],
        "domains": {"instagram.com"},
    },
    "WhatsApp": {
        "keywords": ["whatsapp"], "exact": [],
        "domains": {"whatsapp.com", "whatsapp.net"},
    },
    "LinkedIn": {
        "keywords": ["linkedin"], "exact": [],
        "domains": {"linkedin.com", "lnkd.in"},
    },
    "Netflix": {
        "keywords": ["netflix"], "exact": [],
        "domains": {"netflix.com"},
    },
    "State Bank of India": {
        "keywords": ["onlinesbi"], "exact": ["sbi"],
        "domains": {"sbi.co.in", "onlinesbi.sbi", "onlinesbi.com", "sbicard.com"},
    },
    "HDFC Bank": {
        "keywords": ["hdfcbank"], "exact": ["hdfc"],
        "domains": {"hdfcbank.com"},
    },
    "ICICI Bank": {
        "keywords": ["icicibank"], "exact": ["icici"],
        "domains": {"icicibank.com"},
    },
    "Axis Bank": {
        "keywords": ["axisbank"], "exact": [],
        "domains": {"axisbank.com"},
    },
    "Paytm": {
        "keywords": ["paytm"], "exact": [],
        "domains": {"paytm.com"},
    },
    "PhonePe": {
        "keywords": ["phonepe"], "exact": [],
        "domains": {"phonepe.com"},
    },
    "IRCTC": {
        "keywords": ["irctc"], "exact": [],
        "domains": {"irctc.co.in"},
    },
    "Income Tax Department": {
        "keywords": ["incometax"], "exact": [],
        "domains": {"incometax.gov.in"},
    },
    "Aadhaar (UIDAI)": {
        "keywords": ["aadhaar", "uidai"], "exact": [],
        "domains": {"uidai.gov.in"},
    },
    "Airtel": {
        "keywords": ["airtel"], "exact": [],
        "domains": {"airtel.in", "airtel.com"},
    },
    "Jio": {
        "keywords": [], "exact": ["jio"],
        "domains": {"jio.com"},
    },
}

# Scammers swap letters for look-alike digits/symbols: paypa1, g00gle ...
LEET_MAP = str.maketrans(
    {"0": "o", "1": "l", "3": "e", "4": "a", "5": "s", "@": "a", "$": "s"}
)

SAFE_TIPS = [
    "Do not click links in unexpected SMS, email or WhatsApp messages. Open the "
    "official app or type the website address yourself.",
    "Real banks never ask for your OTP, PIN, CVV or password by link, call or "
    "message.",
    "Be extra careful when a message rushes you: \"account blocked\", \"win a "
    "prize\", \"last chance\". Urgency is the scammer's favourite tool.",
    "Read the domain from right to left before the first single slash. In "
    "'paypal.com.evil.xyz' the real site is evil.xyz, not paypal.com.",
    "A padlock or HTTPS only means the connection is encrypted. Scam sites can "
    "have it too, so it does not prove a site is honest.",
    "Never install an app (.apk) from a link. Use only the official app store.",
    "Turn on two-factor authentication, so a stolen password alone is not "
    "enough.",
    "If you already entered details, change that password immediately and call "
    "your bank. In India you can report cyber fraud at cybercrime.gov.in or on "
    "the 1930 helpline.",
]


# --------------------------------------------------------------------------
# 2. SMALL HELPER FUNCTIONS
# --------------------------------------------------------------------------

def _finding(finding_id, title, explanation, severity, points):
    """Create one 'finding' (one warning sign) as a simple dictionary."""
    return {
        "id": finding_id,
        "title": title,
        "explanation": explanation,
        "severity": severity,  # "low", "medium" or "high"
        "points": points,      # how much it adds to the risk score
    }


def registered_domain(host):
    """
    Return the 'main' domain of a host name.

        www.google.com        -> google.com
        mail.google.co.in     -> google.co.in
        paypal.com.evil.xyz   -> evil.xyz      (this is the one that matters!)

    This is a simple approximation. Big projects use the 'tldextract' library.
    """
    labels = host.split(".")
    if len(labels) <= 2:
        return host
    last_two = ".".join(labels[-2:])
    if last_two in TWO_PART_SUFFIXES:
        return ".".join(labels[-3:])
    return last_two


def _is_ip_address(host):
    """True for hosts like 192.168.1.5 or a long number like 3232235777."""
    if host.isdigit():
        return True
    try:
        ipaddress.ip_address(host)
        return True
    except ValueError:
        return False


def _letter_variants(token):
    """
    Undo common look-alike tricks so 'paypa1' is read as 'paypal' and
    'rnicrosoft' (r + n) is read as 'microsoft'.
    """
    base = token.translate(LEET_MAP)
    return {base, base.replace("rn", "m"), base.replace("vv", "w")}


def _brand_in_host(host, main_domain):
    """
    Look for a famous brand name inside the host name when the main domain is
    NOT really that brand's domain. Returns (brand_name, matching_word) or None.
    """
    words = [w for w in re.split(r"[.\-_]", host) if w]
    for brand, info in BRANDS.items():
        if main_domain in info["domains"]:
            continue  # this really is the brand's own site
        for word in words:
            for variant in _letter_variants(word):
                if variant in info["exact"]:
                    return brand, word
                if any(key in variant for key in info["keywords"]):
                    return brand, word
    return None


def _brand_in_path(path, main_domain, already_found):
    """Brand name in the part AFTER the domain, e.g. evil.com/paypal/login."""
    lowered = path.lower()
    for brand, info in BRANDS.items():
        if brand == already_found or main_domain in info["domains"]:
            continue
        if any(key in lowered for key in info["keywords"]):
            return brand
    return None


def _verdict_for(score):
    """Turn the number into a label, a short summary and advice."""
    if score < 10:
        return {
            "level": "low",
            "label": "No obvious warning signs",
            "summary": (
                "We did not spot common scam patterns in how this link is "
                "written. This does NOT mean it is safe - we only checked the "
                "text of the link."
            ),
            "advice": [
                "If the message was unexpected or pushes you to hurry, treat "
                "it as suspicious anyway.",
                "If it claims to be from a bank or company, open their official "
                "app or type their website address yourself.",
            ],
        }
    if score < 35:
        return {
            "level": "caution",
            "label": "A few warning signs",
            "summary": (
                "This link has some patterns that scammers use, but they can "
                "also appear on honest links. Be careful before you click."
            ),
            "advice": [
                "Do not enter passwords, OTPs or card details unless you are "
                "completely sure who sent the link.",
                "Confirm with the sender using a different way, such as a "
                "phone call to a number you already trust.",
            ],
        }
    if score < 65:
        return {
            "level": "suspicious",
            "label": "Looks suspicious",
            "summary": (
                "Several warning signs match typical phishing links. It is "
                "safest not to open it."
            ),
            "advice": [
                "Do not open the link and do not type any personal details.",
                "If it claims to be your bank or a company, contact them using "
                "the official app or the number printed on your card.",
                "Delete the message, or report it as spam.",
            ],
        }
    return {
        "level": "danger",
        "label": "Very likely a scam link",
        "summary": (
            "This link matches many classic phishing tricks. Treat it as "
            "dangerous."
        ),
        "advice": [
            "Do not open it. Do not forward it.",
            "Never share your OTP, PIN, CVV or password with anyone who "
            "contacted you first.",
            "If you already clicked or entered details, change your passwords "
            "now and call your bank. In India, report fraud at "
            "cybercrime.gov.in or call 1930.",
        ],
    }


def defang(text):
    """
    Make a link harmless to paste into a chat or document, so nobody clicks it
    by accident:  http://evil.xyz  ->  hxxp[:]//evil[.]xyz
    """
    text = re.sub(r"^http", "hxxp", text, flags=re.IGNORECASE)
    return text.replace("://", "[:]//").replace(".", "[.]")


def build_report(result):
    """A short plain-text report that is safe to copy and share."""
    lines = [
        "PhishGuard report",
        "",
        f"Link (made harmless): {result['defanged']}",
        f"Risk score: {result['score']}/100 - {result['verdict']['label']}",
        "",
    ]
    if result["findings"]:
        lines.append("Warning signs:")
        lines += [f"- {f['title']}" for f in result["findings"]]
    else:
        lines.append("Warning signs: none found in the text of the link.")
    lines += ["", "What to do:"]
    lines += [f"- {step}" for step in result["verdict"]["advice"]]
    lines += ["", result["disclaimer"]]
    return "\n".join(lines)


def _anatomy(parsed, host, main_domain, port, had_scheme, is_ip):
    """
    Split the link into labelled parts so the page can show them one by one:
        https://  www.  paypal.com  :8080  /login
    The part that matters is the "owner".
    """
    parts = []
    if had_scheme:
        parts.append({"kind": "scheme", "text": parsed.scheme.lower() + "://",
                      "label": "Protocol"})
    if "@" in parsed.netloc:
        before_at = parsed.netloc.rsplit("@", 1)[0] + "@"
        parts.append({"kind": "userinfo", "text": before_at[:40],
                      "label": "Ignored by the browser"})
    if not is_ip and host != main_domain:
        parts.append({"kind": "subdomain", "text": host[: -len(main_domain)],
                      "label": "Sub-domain"})
    parts.append({"kind": "owner", "text": main_domain,
                  "label": "Address (numbers only)" if is_ip else "Real owner"})
    if port is not None:
        parts.append({"kind": "port", "text": f":{port}", "label": "Port"})
    rest = parsed.path + (f"?{parsed.query}" if parsed.query else "")
    if rest:
        shown = rest if len(rest) <= 70 else rest[:67] + "..."
        parts.append({"kind": "path", "text": shown, "label": "Page"})
    return parts


def _build_result(shown_url, findings, details):
    """Sort the findings, add up the points and package everything."""
    findings.sort(key=lambda f: f["points"], reverse=True)
    score = min(100, sum(f["points"] for f in findings))
    result = {
        "url": shown_url,
        "defanged": defang(shown_url),
        "score": score,
        "verdict": _verdict_for(score),
        "findings": findings,
        "details": details,
        "disclaimer": DISCLAIMER,
    }
    result["report"] = build_report(result)
    return result


# --------------------------------------------------------------------------
# 3. THE MAIN FUNCTION
# --------------------------------------------------------------------------

def analyze_url(raw_url):
    """
    Analyze one link and return a dictionary with:
        url, score (0-100), verdict, findings, details, disclaimer

    Raises ValueError (with a friendly message) if the input is not usable.
    """
    # ---- Step 1: clean and validate the input ----------------------------
    raw = (raw_url or "").strip()
    if not raw:
        raise ValueError("Please paste a link first.")
    if len(raw) > MAX_URL_LENGTH:
        raise ValueError("That link is too long to check (over 2048 characters).")
    if re.search(r"\s", raw):
        raise ValueError(
            "A link should not contain spaces. Please paste only the link."
        )

    lowered = raw.lower()

    # Special case: "links" that run code instead of opening a website.
    if lowered.startswith(DANGEROUS_SCHEMES):
        findings = [_finding(
            "dangerous-scheme",
            "This is not a normal website link",
            "Links that start with javascript:, data: or vbscript: do not open "
            "a website. They can run hidden code in your browser. Normal links "
            "start with http:// or https://.",
            "high", 80,
        )]
        details = {"scheme": lowered.split(":")[0], "host": "",
                   "registered_domain": "", "path": "", "anatomy": [],
                   "is_ip": False}
        return _build_result(raw, findings, details)

    # Did the user type http:// or https:// ?  If not, we add http:// only so
    # the parser can work, and we remember that we guessed.
    had_scheme = bool(re.match(r"^[a-z][a-z0-9+.\-]*://", lowered))
    if had_scheme and not lowered.startswith(("http://", "https://")):
        raise ValueError("Only http:// and https:// links can be checked.")
    url = raw if had_scheme else "http://" + raw

    # ---- Step 2: split the link into its parts ---------------------------
    try:
        parsed = urlparse(url)
        host = (parsed.hostname or "").lower().rstrip(".")
        port = parsed.port
    except ValueError:
        raise ValueError("That does not look like a valid link.") from None
    if not host:
        raise ValueError("We could not find a website address in that link.")
    # A real web address is made of letters, digits, dots and hyphens, and
    # (unless it is an IP address) has at least one dot, like example.com.
    # Anything else is not a link, so we must not hand it a calm verdict.
    if re.search(r"[^\w.\-]", host) or (
            not _is_ip_address(host) and "." not in host):
        raise ValueError(
            "That does not look like a web address. A link needs a name "
            "with a dot in it, like example.com."
        )

    scheme = parsed.scheme.lower()
    is_ip = _is_ip_address(host)
    main_domain = host if is_ip else registered_domain(host)
    findings = []

    # ---- Step 3: run the checks, one by one ------------------------------

    # Check 1: "@" trick  (http://paypal.com@evil.xyz  really goes to evil.xyz)
    if "@" in parsed.netloc:
        findings.append(_finding(
            "at-sign",
            "Contains an '@' symbol before the website name",
            "Everything before the '@' is ignored by the browser. Scammers put "
            "a trusted name there so the link looks honest, but the browser "
            "actually goes to the part AFTER the '@'.",
            "high", 25,
        ))

    # Check 2: IP address instead of a name
    if is_ip:
        findings.append(_finding(
            "ip-address",
            "Uses numbers (an IP address) instead of a website name",
            "Honest companies use a name like 'sbi.co.in'. A link made of "
            "numbers hides who owns the site and is often used for throw-away "
            "scam pages.",
            "high", 30,
        ))

    # Check 3: punycode / look-alike characters from other alphabets
    if "xn--" in host or not host.isascii():
        findings.append(_finding(
            "lookalike-characters",
            "Uses look-alike letters from another alphabet",
            "Some letters from other languages look identical to English "
            "letters (for example a Cyrillic 'a'). Scammers use them to build "
            "a fake 'paypal.com' that is a completely different website.",
            "high", 25,
        ))

    # Check 4: pretending to be a famous brand
    if not is_ip:
        brand_hit = _brand_in_host(host, main_domain)
        brand_name = None
        if brand_hit:
            brand_name, word = brand_hit
            findings.append(_finding(
                "brand-impersonation",
                f"Pretends to be {brand_name}",
                f"The website name contains '{word}', which looks like "
                f"{brand_name}, but the real owner of this address is "
                f"'{main_domain}', not {brand_name}. Always check the LAST "
                f"part before the first single slash - that is the real owner.",
                "high", 35,
            ))
        path_brand = _brand_in_path(
            parsed.path + parsed.query, main_domain, brand_name
        )
        if path_brand:
            findings.append(_finding(
                "brand-in-path",
                f"Mentions {path_brand} in the link, but the site is "
                f"'{main_domain}'",
                f"The name {path_brand} appears after the website name, which "
                f"is just a folder or file name anyone can choose. The site "
                f"itself is '{main_domain}', so it is not {path_brand}.",
                "medium", 15,
            ))

    # Check 5: shortened link
    if main_domain in SHORTENERS:
        findings.append(_finding(
            "url-shortener",
            "Short link that hides the real destination",
            f"'{main_domain}' is a link-shortening service. You cannot see "
            "where the link really goes until you open it, which is exactly "
            "why scammers like them.",
            "medium", 15,
        ))

    # Check 6: dangerous download
    if parsed.path.lower().endswith(RISKY_EXTENSIONS):
        findings.append(_finding(
            "risky-download",
            "Link downloads an app or program file",
            "This link ends with a file type that installs software (like "
            ".apk for Android or .exe for Windows). Fake bank and "
            "'free reward' apps are a common way to steal data.",
            "high", 20,
        ))

    # Check 7: another link hidden inside the link (redirect trick)
    inner = (parsed.path + "?" + parsed.query).lower()
    if re.search(r"https?(://|%3a%2f%2f)", inner):
        findings.append(_finding(
            "embedded-link",
            "Contains another link inside it",
            "A second web address is hidden inside this link. It can be used "
            "to send you from a trusted-looking page to a different, harmful "
            "website without you noticing.",
            "medium", 10,
        ))

    # Check 8: cheap / free domain ending
    tld = host.rsplit(".", 1)[-1] if "." in host else ""
    if tld in SUSPICIOUS_TLDS:
        findings.append(_finding(
            "suspicious-tld",
            f"Uses the '.{tld}' ending",
            f"Endings like '.{tld}' are very cheap or free, so scammers use "
            "them a lot. Many honest sites use them too, so this is only a "
            "small warning sign on its own.",
            "low", 10,
        ))

    # Check 9: too many sub-domains (a.b.c.d.example.com)
    if not is_ip and host != main_domain:
        sub_part = host[: -len(main_domain)].strip(".")
        sub_count = len([s for s in sub_part.split(".") if s])
        if sub_count >= 3:
            findings.append(_finding(
                "many-subdomains",
                "Very long chain of dots in the website name",
                f"This address has {sub_count} extra parts before "
                f"'{main_domain}'. A long chain can push the real owner out "
                "of sight, especially on a small phone screen.",
                "low", 8,
            ))

    # Check 10: many hyphens in the main domain (secure-login-update-bank.com)
    name_part = main_domain.split(".")[0]
    if (not is_ip and not name_part.startswith("xn--")
            and name_part.count("-") >= 2):
        findings.append(_finding(
            "many-hyphens",
            "Many hyphens in the website name",
            "Real companies rarely use names like 'secure-login-bank-update'. "
            "Scammers join several trust words with hyphens to look official.",
            "low", 6,
        ))

    # Check 11: scary / tempting words
    words_text = (host + parsed.path).lower()
    hits = [w for w in SUSPICIOUS_WORDS if w in words_text]
    if hits:
        shown = ", ".join(f"'{w}'" for w in hits[:5])
        points = 5 if len(hits) == 1 else 10 if len(hits) == 2 else 15
        findings.append(_finding(
            "suspicious-words",
            "Contains words often used to pressure or trick people",
            f"The link includes {shown}. Scammers use words like these to ask "
            "for private details or create urgency. Honest sites use them "
            "too, so this is only a hint, never proof.",
            "low" if len(hits) == 1 else "medium", points,
        ))

    # Check 12: no HTTPS (only if the user typed the start of the link)
    if had_scheme and scheme == "http":
        findings.append(_finding(
            "no-https",
            "Does not use HTTPS (no padlock)",
            "The connection is not encrypted, so anything you type could be "
            "read on the way. Note: HTTPS alone does not make a site "
            "trustworthy, but missing HTTPS on a login page is a bad sign.",
            "low", 10,
        ))

    # Check 13: unusual port number
    if port not in (None, 80, 443):
        findings.append(_finding(
            "odd-port",
            f"Uses an unusual port number ({port})",
            "Normal websites almost always use the standard ports. Odd port "
            "numbers appear more often on temporary or hacked servers.",
            "medium", 8,
        ))

    # Check 14: very long link
    if len(url) > 75:
        findings.append(_finding(
            "long-url",
            "Very long link",
            "Long links can hide the important part. Scammers sometimes pad a "
            "link with extra text so you do not notice the real website name.",
            "low", 5,
        ))

    # Check 15: lots of %xx characters
    if url.count("%") >= 6:
        findings.append(_finding(
            "heavy-encoding",
            "Lots of hidden-code characters (%xx)",
            "Many '%' codes can be used to disguise what the link really "
            "contains.",
            "low", 5,
        ))

    # ---- Step 4: package the answer --------------------------------------
    details = {
        "scheme": scheme if had_scheme else "not given (assumed http)",
        "host": host,
        "registered_domain": main_domain,
        "path": (parsed.path or "/")[:120],
        "anatomy": _anatomy(parsed, host, main_domain, port, had_scheme, is_ip),
        "is_ip": is_ip,
    }
    return _build_result(raw, findings, details)
