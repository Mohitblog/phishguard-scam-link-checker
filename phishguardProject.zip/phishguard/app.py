"""
app.py  -  the web server of PhishGuard
=======================================

Pages
    /             check one link, or many links at once
    /model        how the machine-learning model works (and how good it is)
    /api/check    JSON API for one link
    /api/batch    JSON API for many links

Flow:  browser form --> Flask route --> engine.check_url() --> result page
                                         |-- analyzer.py (rules)
                                         '-- ml.py       (machine learning)

Run it with:   python app.py   (or double-click run.bat on Windows)
The web page opens in your browser automatically.
If it does not, open:  http://127.0.0.1:5000
"""

import os
import threading
import webbrowser

from flask import Flask, jsonify, render_template, request

from analyzer import SAFE_TIPS
from engine import MAX_BATCH, check_many, check_url
from ml import model_summary

app = Flask(__name__)

# Example buttons on the page. They are made-up and are never opened.
EXAMPLES = [
    {"label": "Fake PayPal", "url": "http://paypa1-secure-login.xyz/verify/account"},
    {"label": "Fake bank KYC", "url": "http://sbi-kyc-update.top/login?next=http://example.org/otp"},
    {"label": "Name trick", "url": "https://paypal.com.account-check.xyz/signin"},
    {"label": "Short link", "url": "https://bit.ly/3Xy9AbC"},
    {"label": "Normal site", "url": "https://en.wikipedia.org/wiki/Phishing"},
]


@app.route("/", methods=["GET", "POST"])
def index():
    """Home page: show the forms, and show results after a form is sent."""
    context = {
        "mode": "single", "url": "", "urls": "", "result": None,
        "rows": None, "skipped": 0, "error": None,
        "tips": SAFE_TIPS, "examples": EXAMPLES, "max_batch": MAX_BATCH,
    }

    if request.method == "POST":
        if request.form.get("mode") == "batch":
            context["mode"] = "batch"
            context["urls"] = request.form.get("urls", "")
            rows, skipped = check_many(context["urls"])
            if rows:
                context["rows"], context["skipped"] = rows, skipped
            else:
                context["error"] = "Please paste at least one link, one per line."
        else:
            context["url"] = request.form.get("url", "")
            try:
                context["result"] = check_url(context["url"])
            except ValueError as problem:
                context["error"] = str(problem)  # friendly text from analyzer.py

    return render_template("index.html", **context)


@app.route("/model")
def model_page():
    """Explains the machine-learning part and shows how it was tested."""
    return render_template("model.html", summary=model_summary())


@app.route("/api/check", methods=["POST"])
def api_check():
    """
    Check one link and return JSON.

        curl -X POST http://127.0.0.1:5000/api/check \
             -H "Content-Type: application/json" \
             -d '{"url": "http://paypa1-secure-login.xyz"}'
    """
    data = request.get_json(silent=True) or {}
    try:
        return jsonify(check_url(data.get("url", "")))
    except ValueError as problem:
        return jsonify({"error": str(problem)}), 400


@app.route("/api/batch", methods=["POST"])
def api_batch():
    """Check up to 20 links:  {"urls": ["link1", "link2"]}  -> {"results": [...]}"""
    data = request.get_json(silent=True) or {}
    urls = data.get("urls")
    if not isinstance(urls, list) or not urls:
        return jsonify({"error": "Send a JSON list called 'urls'."}), 400
    rows, skipped = check_many("\n".join(str(u) for u in urls))
    return jsonify({"results": rows, "skipped": skipped})


if __name__ == "__main__":
    HOST, PORT = "127.0.0.1", 5000
    PAGE_URL = f"http://{HOST}:{PORT}"

    # Open the web page in your browser automatically, one second after the
    # server starts. To turn this off:  set PHISHGUARD_NO_BROWSER=1
    # (WERKZEUG_RUN_MAIN avoids opening it twice when debug mode restarts.)
    if (os.environ.get("PHISHGUARD_NO_BROWSER") != "1"
            and os.environ.get("WERKZEUG_RUN_MAIN") != "true"):
        threading.Timer(1.0, lambda: webbrowser.open(PAGE_URL)).start()

    print(f"PhishGuard is running at {PAGE_URL}  (press Ctrl+C to stop)")

    # Debug mode shows detailed errors - great while learning, but never leave
    # it on for a public website. Turn it on with:  FLASK_DEBUG=1 python app.py
    app.run(host=HOST, port=PORT, debug=os.environ.get("FLASK_DEBUG") == "1")
