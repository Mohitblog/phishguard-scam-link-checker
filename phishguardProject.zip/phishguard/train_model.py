"""
train_model.py  -  teach the computer to spot scam links
========================================================

Run it:                 python train_model.py
Use your own data:      python train_model.py --csv my_links.csv
Needs (training only):  pip install scikit-learn numpy

WHAT HAPPENS
------------
1. We get labelled links: (link, 1 = scam) or (link, 0 = normal).
2. Each link is turned into 26 numbers by ml.extract().
3. 80% of the links are used to TRAIN a Logistic Regression model.
   The other 20% are hidden and used to TEST it, which tells us if it
   learned something real or just memorised the training links.
4. The learned weights are saved to model.json.

IMPORTANT - BE HONEST ABOUT THE DATA
------------------------------------
Without --csv this script GENERATES example links from patterns (synthetic
data). That is fine for a demo and for learning how the pipeline works, but:
  * the test scores only tell you how well the model learned OUR generator,
  * they do NOT tell you how well it would do on scams found in the wild.
For a stronger project, train on a real dataset (see README) with --csv.

CSV format:  two columns named  url,label   (label 1 = phishing, 0 = normal)
"""

import argparse
import csv
import json
import random
import string
from datetime import date

import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score,
                             precision_score, recall_score)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

import ml

# --------------------------------------------------------------------------
# 1. SYNTHETIC DATA GENERATOR (used when no --csv file is given)
# --------------------------------------------------------------------------

LEGIT_DOMAINS = [
    "google.com", "wikipedia.org", "github.com", "stackoverflow.com",
    "amazon.in", "amazon.com", "flipkart.com", "youtube.com", "linkedin.com",
    "microsoft.com", "apple.com", "paypal.com", "netflix.com", "facebook.com",
    "instagram.com", "whatsapp.com", "twitter.com", "reddit.com", "quora.com",
    "medium.com", "bbc.com", "nytimes.com", "thehindu.com", "ndtv.com",
    "timesofindia.indiatimes.com", "sbi.co.in", "hdfcbank.com", "icicibank.com",
    "axisbank.com", "paytm.com", "phonepe.com", "irctc.co.in", "uidai.gov.in",
    "incometax.gov.in", "nitp.ac.in", "iitb.ac.in", "mit.edu", "stanford.edu",
    "coursera.org", "udemy.com", "kaggle.com", "python.org", "flask.palletsprojects.com",
    "docs.python.org", "w3schools.com", "geeksforgeeks.org", "swiggy.com",
    "zomato.com", "myntra.com", "naukri.com", "airtel.in", "jio.com",
    "dropbox.com", "zoom.us", "slack.com", "notion.so", "spotify.com",
    "adobe.com", "ebay.com", "walmart.com", "bankofamerica.com", "chase.com",
]
WORDS = [
    "green", "leaf", "code", "camp", "blue", "star", "fresh", "daily", "smart",
    "city", "book", "store", "photo", "travel", "food", "music", "game", "tech",
    "learn", "health", "garden", "coffee", "river", "mountain", "studio",
    "design", "market", "news", "sports", "kitchen", "cloud", "pixel", "nest",
    "orbit", "maple", "tiger", "lotus", "coral", "amber", "cedar",
]
BRANDS = [
    "paypal", "amazon", "google", "microsoft", "apple", "facebook", "instagram",
    "netflix", "sbi", "hdfcbank", "icicibank", "axisbank", "paytm", "phonepe",
    "flipkart", "irctc", "whatsapp", "linkedin", "airtel", "jio", "incometax",
    "aadhaar", "uidai",
]
PHISH_WORDS = [
    "login", "secure", "verify", "update", "account", "kyc", "otp", "confirm",
    "reward", "refund", "support", "bonus", "claim", "unlock", "alert",
    "payment", "wallet", "banking", "service", "help",
]
CHEAP_TLDS = ["xyz", "top", "tk", "ml", "ga", "cf", "gq", "click", "link",
              "work", "support", "buzz", "icu", "cam", "rest"]
NORMAL_TLDS = ["com", "in", "org", "net", "co.in"]
FREE_HOSTS = ["weebly.com", "000webhostapp.com", "blogspot.com", "netlify.app",
              "pages.dev", "web.app", "github.io", "wixsite.com", "glitch.me"]
SHORTENERS = ["bit.ly", "tinyurl.com", "t.co", "cutt.ly", "rb.gy", "is.gd", "shorturl.at"]

LEGIT_PATHS = [
    "", "/", "/", "/wiki/{word}", "/products/{n}", "/search?q={word}", "/login",
    "/signin", "/account/settings", "/blog/{word}-{word2}", "/watch?v={tok}",
    "/docs/{word}/intro", "/orders", "/help/payment", "/courses/{word}",
    "/in/{word}-{word2}", "/article/{n}/{word}", "/about", "/contact",
    "/category/{word}?page={n}&sort=new", "/verify-email", "/support",
    "/user/{word}/profile", "/shop/{word}/item-{n}",
]
PHISH_PATHS = [
    "", "/", "/login", "/login.php", "/verify", "/verify/account", "/update",
    "/secure/login", "/signin.html", "/kyc/verify?id={n}", "/otp", "/confirm",
    "/account/update", "/claim-reward", "/wp-content/login.php", "/index.php?id={tok}",
    "/refund/{n}", "/auth/{tok}", "/payment/verify", "/{tok}/login",
]


def _token(rng, n):
    return "".join(rng.choice(string.ascii_lowercase + string.digits) for _ in range(n))


def _fill(rng, template):
    return template.format(
        word=rng.choice(WORDS), word2=rng.choice(WORDS),
        n=rng.randint(1, 99999), tok=_token(rng, rng.randint(6, 12)),
    )


def _scheme(rng, https_chance):
    return "https://" if rng.random() < https_chance else "http://"


def make_legit(rng):
    kind = rng.random()
    if kind < 0.52:
        sub = rng.choice(["", "", "www.", "www.", "m.", "mail.", "accounts.",
                          "docs.", "support.", "blog.", "en.", "help."])
        host = sub + rng.choice(LEGIT_DOMAINS)
    elif kind < 0.82:
        name = rng.choice(WORDS) + (rng.choice(WORDS) if rng.random() < 0.5 else "")
        if rng.random() < 0.12:
            name = name[: len(name) // 2] + "-" + name[len(name) // 2:]
        tld = rng.choice(CHEAP_TLDS) if rng.random() < 0.07 else rng.choice(NORMAL_TLDS)
        host = ("www." if rng.random() < 0.4 else "") + name + "." + tld
    elif kind < 0.92:
        host = rng.choice(WORDS) + rng.choice(WORDS) + "." + rng.choice(FREE_HOSTS)
    elif kind < 0.975:
        host = rng.choice(SHORTENERS)
        return _scheme(rng, 0.97) + host + "/" + _token(rng, rng.randint(5, 8))
    else:
        host = f"192.168.{rng.randint(0, 5)}.{rng.randint(1, 254)}"
        return "http://" + host + rng.choice(["/", "/admin", "/login"])
    url = _scheme(rng, 0.93) + host + _fill(rng, rng.choice(LEGIT_PATHS))
    if rng.random() < 0.02:
        url += "&next=https://" + rng.choice(LEGIT_DOMAINS)
    return url


def make_phish(rng):
    brand = rng.choice(BRANDS)
    word = rng.choice(PHISH_WORDS)
    word2 = rng.choice(PHISH_WORDS)
    tld = rng.choice(CHEAP_TLDS) if rng.random() < 0.7 else rng.choice(NORMAL_TLDS)
    rand = _token(rng, rng.randint(5, 10))
    kind = rng.random()
    path = _fill(rng, rng.choice(PHISH_PATHS))

    if kind < 0.24:                       # paypal-secure-login.xyz
        sep = rng.choice(["-", "-", ""])
        host = f"{brand}{sep}{word}{sep}{word2 if rng.random() < 0.4 else ''}".rstrip("-")
        host = host + "." + tld
    elif kind < 0.40:                     # paypa1 / amaz0n  (look-alike letters)
        leet = brand.replace("a", "4" if rng.random() < 0.3 else "a")
        for old, new in (("l", "1"), ("o", "0"), ("e", "3"), ("i", "1")):
            if old in leet and rng.random() < 0.6:
                leet = leet.replace(old, new, 1)
                break
        host = f"{leet}-{word}.{tld}" if rng.random() < 0.6 else f"{leet}.{tld}"
    elif kind < 0.55:                     # paypal.com.evil.xyz
        host = f"{brand}.com.{rand}.{tld}" if rng.random() < 0.6 else \
               f"{word}.{brand}.com-{word2}.{tld}"
    elif kind < 0.63:                     # raw IP address
        host = f"{rng.randint(11, 223)}.{rng.randint(0, 255)}.{rng.randint(0, 255)}.{rng.randint(1, 254)}"
        if rng.random() < 0.3:
            host += f":{rng.choice([8080, 8000, 8443, 3000])}"
    elif kind < 0.69:                     # paypal.com@evil.xyz
        host = f"{brand}.com@{rand}.{tld}"
    elif kind < 0.78:                     # short link
        return _scheme(rng, 0.9) + rng.choice(SHORTENERS) + "/" + _token(rng, rng.randint(5, 8))
    elif kind < 0.86:                     # normal-looking name, scammy path
        host = rng.choice(WORDS) + rng.choice(WORDS) + "." + rng.choice(NORMAL_TLDS)
        path = _fill(rng, rng.choice(PHISH_PATHS[4:]))
    elif kind < 0.93:                     # free hosting abuse
        host = f"{brand}-{word}.{rng.choice(FREE_HOSTS)}"
    else:                                 # fake app download
        host = f"{rand}.{tld}"
        path = f"/{brand}-{rng.choice(['rewards', 'app', 'update', 'kyc'])}.apk"

    url = _scheme(rng, 0.45) + host + path
    if rng.random() < 0.08:
        url += ("&" if "?" in url else "?") + "redirect=http://" + _token(rng, 8) + "." + tld
    return url


def generate_dataset(per_class=4000, seed=42, label_noise=0.03):
    """Make labelled example links. 3% of labels are flipped on purpose, because
    real-world data is never perfectly clean."""
    rng = random.Random(seed)
    rows = []
    for _ in range(per_class):
        rows.append((make_legit(rng), 0))
        rows.append((make_phish(rng), 1))
    for i, (url, label) in enumerate(rows):
        if rng.random() < label_noise:
            rows[i] = (url, 1 - label)
    rng.shuffle(rows)
    return rows


def read_csv(path):
    rows = []
    with open(path, newline="", encoding="utf-8") as handle:
        for record in csv.DictReader(handle):
            url = (record.get("url") or "").strip()
            label = str(record.get("label", "")).strip().lower()
            if not url:
                continue
            if label in ("1", "phishing", "bad", "malicious", "scam"):
                rows.append((url, 1))
            elif label in ("0", "legitimate", "benign", "good", "normal"):
                rows.append((url, 0))
    return rows


# --------------------------------------------------------------------------
# 2. TRAIN, TEST, SAVE
# --------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Train the PhishGuard model.")
    parser.add_argument("--csv", help="CSV file with columns: url,label (1 = phishing)")
    parser.add_argument("--out", default=ml.MODEL_PATH, help="where to save model.json")
    args = parser.parse_args()

    if args.csv:
        rows = read_csv(args.csv)
        source = f"real dataset: {args.csv}"
    else:
        rows = generate_dataset()
        source = "synthetic example links generated by train_model.py (demo data)"
    print(f"Loaded {len(rows)} labelled links from {source}")

    # --- turn links into numbers ---
    X, y = [], []
    for url, label in rows:
        try:
            X.append(ml.extract(url))
            y.append(label)
        except ValueError:
            continue  # skip anything we cannot parse
    X, y = np.array(X), np.array(y)
    print(f"Usable links: {len(y)}  (scam: {int(y.sum())}, normal: {int(len(y) - y.sum())})")

    # --- split: 80% to learn from, 20% hidden for testing ---
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    # --- train the model we will actually use (explainable) ---
    scaler = StandardScaler().fit(X_train)
    model = LogisticRegression(max_iter=2000, C=1.0)
    model.fit(scaler.transform(X_train), y_train)
    predicted = model.predict(scaler.transform(X_test))

    metrics = {
        "accuracy": accuracy_score(y_test, predicted),
        "precision": precision_score(y_test, predicted),
        "recall": recall_score(y_test, predicted),
        "f1": f1_score(y_test, predicted),
        "test_size": int(len(y_test)),
    }
    tn, fp, fn, tp = confusion_matrix(y_test, predicted).ravel()
    metrics.update({"true_negative": int(tn), "false_positive": int(fp),
                    "false_negative": int(fn), "true_positive": int(tp)})

    # --- for comparison only: a stronger but less explainable model ---
    forest = RandomForestClassifier(n_estimators=200, random_state=42, n_jobs=-1)
    forest.fit(X_train, y_train)
    forest_accuracy = accuracy_score(y_test, forest.predict(X_test))

    print("\nResults on the 20% of links the model never saw while learning:")
    print(f"  Accuracy  : {metrics['accuracy']:.1%}   (share of links classified correctly)")
    print(f"  Precision : {metrics['precision']:.1%}   (when it says 'scam', how often is it right)")
    print(f"  Recall    : {metrics['recall']:.1%}   (share of real scams it catches)")
    print(f"  F1 score  : {metrics['f1']:.1%}   (balance of precision and recall)")
    print(f"  Missed scams: {fn}   False alarms: {fp}")
    print(f"  (Random Forest for comparison: {forest_accuracy:.1%} accuracy)")

    # --- save as plain numbers ---
    saved = {
        "feature_names": ml.FEATURE_NAMES,
        "mean": scaler.mean_.tolist(),
        "scale": [s if s else 1.0 for s in scaler.scale_.tolist()],
        "coef": model.coef_[0].tolist(),
        "intercept": float(model.intercept_[0]),
        "metrics": metrics,
        "trained_on": {
            "source": source,
            "links": int(len(y)),
            "synthetic": args.csv is None,
            "date": date.today().isoformat(),
            "algorithm": "Logistic Regression (scikit-learn)",
            "random_forest_accuracy": forest_accuracy,
        },
    }
    with open(args.out, "w", encoding="utf-8") as handle:
        json.dump(saved, handle, indent=2)
    print(f"\nSaved the trained model to {args.out}")


if __name__ == "__main__":
    main()
